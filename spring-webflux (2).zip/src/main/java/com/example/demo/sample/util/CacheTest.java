package com.example.demo.sample.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Component;

@Component
public class CacheTest {
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Cacheable(value = "persons" , key = "#id")
	public String test(String id) {
		
		logger.info("in method");
		
		return "test";
	}
	
}
